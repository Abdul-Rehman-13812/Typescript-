let  number  = 3;
console.log(number);

 let greeding : string = "Aslam O Alikum";
 console.log(greeding);

 greeding.toUpperCase()

 console.log(greeding);

 let num : number = 381 ;
 console.log (num);

 let isloogin : boolean = false;
 console.log(isloogin);
 

 function addtwonum(num :number){
    return num+2;

 }
addtwonum(5);
console.log(num);

function sigup (name:string , email:string , ispaid:boolean)
{}

sigup("Abdulrehman","arifabdulrehman37@gmail.com",true);
console.log(sigup);


function getvalue (value1 : number){
    if(value1>5){
        return true;
    }
    return "100 arif";
}
const getvalue1 = (s:string ) :string =>{
    return  "Andulrehamn";
}
console.log(getvalue1);

const hero = ["Abdulrehman ", "Abdullah ","Thor"]
hero.map ((heros):string => {
    return `hero is ${heros}`

})
 console.log(hero);
function consolemessage (errmsg : string ):void {
    console.log(errmsg);
}

function handekmessage(errrmsgg : string  ) : never{
    throw new Error(errrmsgg);
 
}

//objects
const user = {
    name:"Abdul rehman",
    email:"Arifabdulrehman@gmail.com",
    ISactive:true

}

function usersdetails  ({name : string , ispaid:boolean}){

  let   newusersdetails = ({name:"abdulrehman",ispaid:false , email:"arifabdulrehman@gmail,com"});
   // usersdetails(newusersdetails);

}




export{}
